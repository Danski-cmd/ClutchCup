const SK=['Rookie','Casual','Solid','Skilled','Elite'];
const G={
 valorant:{n:'Valorant',z:5,m:{x:{n:'Ranked',r:['Iron','Bronze','Silver','Gold','Platinum','Diamond','Ascendant','Immortal','Radiant']}}},
 cs2:{n:'CS2',z:5,m:{comp:{n:'Competitive',r:['Silver I','Silver II','Silver III','Silver IV','Silver Elite','Silver Elite Master','Gold Nova I','Gold Nova II','Gold Nova III','Gold Nova Master','Master Guardian I','Master Guardian II','Master Guardian Elite','Distinguished MG','Legendary Eagle','Legendary Eagle Master','Supreme','Global Elite']},premier:{n:'Premier',num:1,max:35000},faceit:{n:'FACEIT',r:['Level 1 (100–500)','Level 2 (501–750)','Level 3 (751–900)','Level 4 (901–1050)','Level 5 (1051–1200)','Level 6 (1201–1350)','Level 7 (1351–1530)','Level 8 (1531–1750)','Level 9 (1751–2000)','Level 10 (2001+)']}}},
 fifa:{n:'FIFA',z:2,m:{x:{n:'Skill',r:SK}}},
 football:{n:'Football',z:5,m:{x:{n:'Skill',r:SK}}},
 basketball:{n:'Basketball',z:3,m:{x:{n:'Skill',r:SK}}}
};
const NATO=['Alpha','Bravo','Charlie','Delta','Echo','Foxtrot','Golf','Hotel','India','Juliet','Kilo','Lima'];
const DEMO=['Ace','Blaze','Cipher','Dash','Echo','Frost','Ghost','Hawk','Ivy','Jinx'];
const $=s=>document.querySelector(s),app=$('#app'),rnd=n=>Math.floor(Math.random()*n);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function load(){try{const s=JSON.parse(localStorage.getItem('clutchcup3'));return s&&G[s.g]&&G[s.g].m[s.m]?s:null}catch(e){return null}}
function save(){try{localStorage.setItem('clutchcup3',JSON.stringify(S))}catch(e){}}
let S=load()||{g:'valorant',m:'x',z:5,p:[],t:[],R:[]};

const M=()=>G[S.g].m[S.m];
const TIER=['#9aa5b5','#6fc3ff','#4d7cff','#a05bff','#ff5fd2','#ff4d4d','#f5c542']; // Premier colour bands, one per 5,000 rating
const fr=(p,m)=>m.num?Math.min(p.r,m.max)/m.max:p.r/(m.r.length-1); // 0 to 1 skill fraction in any rating system
const rl=p=>M().num?p.r.toLocaleString('en-US'):M().r[p.r];
const bs=p=>1+9*fr(p,M());
const w=p=>Math.pow(bs(p),1.4); // higher ranks count for much more than lower ones
const col=p=>M().num?TIER[Math.min(6,Math.floor(p.r/5000))]:`hsl(${215-195*fr(p,M())} 80% 52%)`;
const avg=t=>t.reduce((s,p)=>s+w(p),0)/t.length;
const dirty=()=>{S.t=[];S.R=[]};
function setGame(g,k){const o=M(),f=S.p.map(p=>fr(p,o));if(!k)S.z=G[g].z;S.g=g;S.m=k||Object.keys(G[g].m)[0];const n=M();S.p.forEach((p,i)=>p.r=n.num?Math.round(f[i]*n.max/100)*100:Math.round(f[i]*(n.r.length-1)));dirty()}

function balance(){
 const P=S.p;if(P.length<2)return;
 const k=Math.max(2,Math.round(P.length/S.z));
 let best=null,bc=Infinity;
 for(let t=0;t<60;t++){
  const T=Array.from({length:k},()=>[]);
  [...P].sort(()=>Math.random()-.5).forEach((p,i)=>T[i%k].push(p));
  const cost=()=>{const a=T.map(avg),m=a.reduce((x,y)=>x+y)/k;return(Math.max(...a)-Math.min(...a))*20+a.reduce((s,x)=>s+(x-m)*(x-m),0)}; // spread first, then variance
  let c=cost();
  for(let i=0;i<1500;i++){
   const a=rnd(k),b=rnd(k);if(a===b)continue;
   const x=rnd(T[a].length),y=rnd(T[b].length);
   [T[a][x],T[b][y]]=[T[b][y],T[a][x]];
   const n=cost();
   if(n<=c)c=n;else[T[a][x],T[b][y]]=[T[b][y],T[a][x]];
  }
  if(c<bc){bc=c;best=T}
 }
 S.t=best.map((m,i)=>({n:S.z===1?m[0].n:(NATO[i]||'Team '+(i+1)),m:m.sort((a,b)=>b.r-a.r)}));
 S.R=[];
}

function seed(){
 const T=S.t.map((_,i)=>i).sort(()=>Math.random()-.5);
 let sz=2;while(sz<T.length)sz*=2;
 let o=[1];while(o.length<sz)o=o.flatMap(x=>[x,o.length*2+1-x]);
 const slot=s=>s<=T.length?T[s-1]:null;
 const r0=[];for(let i=0;i<sz;i+=2)r0.push({a:slot(o[i]),b:slot(o[i+1]),sa:'',sb:''});
 S.R=[r0];
 for(let n=sz/4;n>=1;n/=2)S.R.push(Array.from({length:n},()=>({a:null,b:null,sa:'',sb:''})));
 sync();
}
function W(r,i){
 const m=S.R[r][i];
 if(r===0){if(m.a==null&&m.b!=null)return m.b;if(m.b==null&&m.a!=null)return m.a}
 if(m.a==null||m.b==null||m.sa===''||m.sb===''||+m.sa===+m.sb)return null;
 return +m.sa>+m.sb?m.a:m.b;
}
function sync(){
 S.R.forEach((R,r)=>{if(r>0)R.forEach((m,i)=>{
  const a=W(r-1,2*i),b=W(r-1,2*i+1);
  if(m.a!==a||m.b!==b){m.a=a;m.b=b;m.sa=m.sb=''}
 })});
}

function render(){
 const g=M(),n=S.p.length,k=Math.max(2,Math.round(n/S.z)),mid=g.num?0:Math.floor(g.r.length/2);
 let h=`<h1>Clutch Cup</h1><p class="mute">Add your friends and their ranks. Get fair teams and a knockout bracket in seconds.</p>`;
 h+=`<h2>1. Game and players</h2><div class="row">${Object.keys(G).map(key=>`<button data-a="game" data-v="${key}" class="${key===S.g?'on':''}">${G[key].n}</button>`).join('')}
 </div>${Object.keys(G[S.g].m).length>1?`<div class="row" style="margin-top:8px"><span class="mute">Rating system</span>${Object.keys(G[S.g].m).map(q=>`<button data-a="mode" data-v="${q}" class="${q===S.m?'on':''}">${G[S.g].m[q].n}</button>`).join('')}</div>`:''}<div class="row" style="margin-top:8px"><label class="row mute">Players per team <select data-f="sz">${[1,2,3,4,5,7,11].map(v=>`<option ${v===S.z?'selected':''}>${v}</option>`).join('')}</select></label></div>`;
 h+=`<div class="row" style="margin:14px 0"><input id="nm" placeholder="Player name" maxlength="20" aria-label="Player name">${g.num?`<input id="rk" class="rt" type="number" min="0" max="40000" step="100" value="15000" aria-label="Premier rating">`:`<select id="rk" aria-label="Rank">${g.r.map((x,i)=>`<option value="${i}" ${i===mid?'selected':''}>${x}</option>`).join('')}</select>`}<button class="p" data-a="add">Add player</button><button data-a="demo">Add sample squad</button></div>`;
 h+=n?`<div class="grid">${S.p.map((p,i)=>`<div class="box pl"><i class="dot" style="background:${col(p)}"></i><span style="flex:1;overflow:hidden;text-overflow:ellipsis">${esc(p.n)}</span>${g.num?`<input class="rt" type="number" min="0" max="40000" step="100" data-f="rank" data-i="${i}" value="${p.r}" aria-label="Rating of ${esc(p.n)}">`:`<select data-f="rank" data-i="${i}" aria-label="Rank of ${esc(p.n)}">${g.r.map((x,j)=>`<option value="${j}" ${j===p.r?'selected':''}>${x}</option>`).join('')}</select>`}<button class="x" data-a="del" data-i="${i}" aria-label="Remove ${esc(p.n)}">×</button></div>`).join('')}</div>`:`<p class="mute">No players yet. Add at least two, or try the sample squad.</p>`;
 h+=`<div class="row" style="margin-top:14px"><button class="p" data-a="bal" ${n<2?'disabled':''}>Balance teams</button><span class="mute">${n>=2?`${n} players make ${k} teams of about ${Math.round(n/k*10)/10}.`:''}</span></div>`;
 if(S.t.length){
  const A=S.t.map(t=>avg(t.m)),mx=Math.max(...A),mn=Math.min(...A),mean=A.reduce((a,b)=>a+b)/A.length,bal=Math.max(0,Math.round(100*(1-(mx-mn)/mean)));
  const dv=A.map(x=>(x/mean-1)*100),ar=S.t.map(t=>t.m.reduce((q,p)=>q+p.r,0)/t.m.length),arl=x=>g.num?Math.round(x).toLocaleString('en-US'):g.r[Math.round(x)],vd=bal>=97?'Perfectly balanced':bal>=92?'Very balanced':bal>=85?'Fairly balanced':'Uneven';
  h+=`<h2>2. Teams</h2>${S.z===1?`<div class="box"><p>1v1 mode: every player is their own team, so there are no groups to balance. Set players per team to 2 or more to build balanced pairs or squads.</p></div>`:`<div class="box"><div class="bal"><b>${bal}%</b><span><span class="vd">${vd}</span><br><span class="mute">Compares the strongest and weakest team by average player power. 100% means identical. Top ranks are spread across teams and paired with lower ranks.</span></span></div><div style="overflow-x:auto"><table class="tb"><tr><th>Team</th><th>Players</th><th>Avg rank</th><th>Power</th><th>Compared with average</th></tr>${S.t.map((t,i)=>`<tr><td>${esc(t.n)}</td><td>${t.m.length}</td><td>${arl(ar[i])}</td><td>${A[i].toFixed(1)}</td><td><span class="dv"><i style="width:${Math.min(50,Math.abs(dv[i])*5)}%;${dv[i]<0?'right':'left'}:50%"></i></span> ${dv[i]>0?'+':''}${dv[i].toFixed(1)}%</td></tr>`).join('')}</table></div>${new Set(S.t.map(t=>t.m.length)).size>1?'<p class="mute">Teams differ by one player, so power uses each team\u2019s average.</p>':''}</div>`}`;
  h+=`<div class="grid">${S.t.map((t,i)=>`<div class="box tm"><div class="row sp"><h3>${esc(t.n)}</h3><span class="mute">Power ${A[i].toFixed(1)}</span></div>${t.m.map(p=>`<div class="pl"><i class="dot" style="background:${col(p)}"></i><span style="flex:1">${esc(p.n)}</span><span class="mute">${rl(p)}</span></div>`).join('')}</div>`).join('')}</div>`;
  h+=`<div class="row" style="margin-top:14px"><button data-a="bal">Reshuffle</button><button class="p" data-a="seed">${S.R.length?'Redraw bracket':'Start bracket'}</button></div>`;
 }
 if(S.R.length){
  const nr=S.R.length,ch=W(nr-1,0);
  h+=`<h2>3. Bracket</h2>${ch!=null?`<div class="champ">${esc(S.t[ch].n)} win the cup</div>`:''}<div class="br">`;
  S.R.forEach((R,r)=>{
   h+=`<div class="col"><p class="mute" style="margin:0">${r===nr-1?'Final':r===nr-2?'Semi-finals':r===nr-3?'Quarter-finals':'Round '+(r+1)}</p>`;
   R.forEach((m,i)=>{
    const wn=W(r,i);
    h+=`<div class="box">${['a','b'].map(s=>{
     const id=m[s],won=wn!=null&&wn===id;
     return `<div class="t ${won?'w':''}"><span>${id==null?`<span class="mute">${r===0?'BYE':'TBD'}</span>`:esc(S.t[id].n)}</span>${id!=null&&m.a!=null&&m.b!=null?`<input class="sc" type="number" min="0" inputmode="numeric" data-f="sc" data-r="${r}" data-i="${i}" data-s="${s}" value="${m['s'+s]}" aria-label="Score for ${esc(S.t[id].n)}">`:''}</div>`}).join('')}</div>`;
   });
   h+=`</div>`;
  });
  h+=`</div><p class="mute">Enter both scores to move the winner forward. Draws are not allowed, so play a tiebreaker.</p>`;
 }
 app.innerHTML=h;
}

app.addEventListener('click',e=>{
 const b=e.target.closest('[data-a]');if(!b)return;
 const a=b.dataset.a;
 if(a==='game')setGame(b.dataset.v);
 else if(a==='mode')setGame(S.g,b.dataset.v);
 else if(a==='add'){const n=$('#nm').value.trim();if(!n){$('#nm').focus();return}const v=$('#rk').value;if(M().num&&v===''){$('#rk').focus();return}S.p.push({n,r:M().num?Math.max(0,Math.min(40000,Math.round(+v))):+v});dirty()}
 else if(a==='demo'){DEMO.forEach(n=>S.p.push({n,r:M().num?(3+rnd(25))*1000:rnd(M().r.length)}));dirty()}
 else if(a==='del'){S.p.splice(+b.dataset.i,1);dirty()}
 else if(a==='bal')balance();
 else if(a==='seed')seed();
 save();render();
 if(a==='add')$('#nm').focus();
});
app.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='nm')$('[data-a="add"]').click()});
app.addEventListener('change',e=>{
 const t=e.target,f=t.dataset.f;if(!f)return;
 if(f==='sz'){S.z=+t.value;dirty()}
 else if(f==='rank'){S.p[+t.dataset.i].r=M().num?Math.max(0,Math.min(40000,Math.round(+t.value||0))):+t.value;dirty()}
 else if(f==='sc'){S.R[+t.dataset.r][+t.dataset.i]['s'+t.dataset.s]=t.value;sync()}
 save();render();
});
render();
